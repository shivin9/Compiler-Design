#include "symData.h"

int checkAssign(parseTree ast){

}